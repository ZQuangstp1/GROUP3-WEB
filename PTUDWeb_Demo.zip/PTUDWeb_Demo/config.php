<?php
define("HOST", "localhost");
define("DB", "db_jewelry"); 
define("USER", "root"); 
define("PASSWORD", "");
?>